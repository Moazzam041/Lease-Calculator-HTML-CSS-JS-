document.getElementById("find-rate-button").addEventListener("click", function() {
    document.querySelector(".bclick").style.display = "none";
    document.querySelector("div1").style.display = "flex";
});

document.getElementById("cross").addEventListener("click", function() {
	document.querySelector(".bclick").style.display = "flex";

    document.querySelector("div1").style.display = "none";
});

document.getElementById("view-more").addEventListener("click", function() {
    document.querySelector(".viewmore").style.display = "flex";
	document.querySelector(".vm").style.display="none";
});

document.getElementById("view-less").addEventListener("click", function() {
    document.querySelector(".viewmore").style.display = "none";
	document.querySelector(".vm").style.display="initial";
});



document.getElementById("calculate-button").addEventListener("click", calculateRates);

function calculateRates() {
	document.querySelector(".results").style.display = "flex";
    document.querySelector(".result1").style.display = "none";
	
    const income = parseFloat(document.getElementById("income").value);
    const avgTransaction = parseFloat(document.getElementById("avg-transaction").value);
    const currentProvider = document.getElementById("current-provider").value;

    // Calculate the transaction fee based on income
    const transactionFee = income * 0.02; // Assuming a 2% transaction fee, you can adjust this value

    // Calculate In-Person Rate and Online Rate by considering the transaction fee
    let inPersonRate = (0.0166 * avgTransaction + 6) + transactionFee;
    let onlineRate = (0.0166 * avgTransaction + 6) + transactionFee;

    // Adjust rates based on the selected current provider
    if (currentProvider === "provider1") {
        inPersonRate = inPersonRate * 1.1; // Increase by 10% for provider 1
        onlineRate = onlineRate * 0.9; // Decrease by 10% for provider 1
    } else if (currentProvider === "provider2") {
        inPersonRate = inPersonRate * 0.9; // Decrease by 10% for provider 2
        onlineRate = onlineRate * 1.1; // Increase by 10% for provider 2
    } else if (currentProvider === "provider3") {
        inPersonRate = inPersonRate * 1.2; // Decrease by 10% for provider 2
        onlineRate = onlineRate * 1.1; // Increase by 10% for provider 2
    } 

    // Calculate potential savings per year in USD
    const savingsPerYear = (inPersonRate - onlineRate) * avgTransaction * 12; // Assuming 12 transactions per year

    // Calculate the percentage savings
    const percentageSavings = ((inPersonRate - onlineRate) / inPersonRate) * 100;

    // Display "In-Person Rate" and "Online Rate" in remainder or percentage form
    document.getElementById("inperson-rate").textContent = inPersonRate.toFixed(2) + " +"; // Display in remainder form
    document.getElementById("online-rate").textContent = onlineRate.toFixed(2) + " +"; // Display in remainder form

    // Display potential savings per year in USD
    document.getElementById("savings-per-year").textContent = savingsPerYear.toFixed(2) + " USD/yr.";

    // Display the percentage savings in the message
    document.getElementById("fee-savings-message").textContent = `Save up to ${percentageSavings.toFixed(2)}% in fees compared to Market Flat-Rates`;
	
	const inpersonOnlineSlider = document.getElementById("inperson-online-slider");
inpersonOnlineSlider.value = Math.floor(Math.random() * (inpersonOnlineSlider.max - inpersonOnlineSlider.min + 1)) + parseInt(inpersonOnlineSlider.min);

// Function to update results based on slider value
function updateResults() {
    const inpersonOnlineValue = parseFloat(inpersonOnlineSlider.value);
    const income = parseFloat(document.getElementById("income").value);
    const avgTransaction = parseFloat(document.getElementById("avg-transaction").value);

    // Recalculate rates and savings based on the slider value
    let inPersonRate = (0.0166 * avgTransaction + 6) + (income * 0.02) + (inpersonOnlineValue / 100 * 10);
    let onlineRate = (0.0166 * avgTransaction + 6) + (income * 0.02) - (inpersonOnlineValue / 100 * 10);

    // Calculate potential savings per year in USD
    const savingsPerYear = (inPersonRate - onlineRate) * avgTransaction * 12;

    // Calculate the percentage savings
    const percentageSavings = ((inPersonRate - onlineRate) / inPersonRate) * 100;

    // Display updated results
    document.getElementById("inperson-rate").textContent = inPersonRate.toFixed(2) + " +";
    document.getElementById("online-rate").textContent = onlineRate.toFixed(2) + " +";
    document.getElementById("savings-per-year").textContent = savingsPerYear.toFixed(2) + " USD/yr.";
    document.getElementById("fee-savings-message").textContent = `Save up to ${percentageSavings.toFixed(2)}% in fees compared to Market Flat-Rates`;
}

// Add an event listener to update results when the slider is moved
inpersonOnlineSlider.addEventListener("input", updateResults);
inpersonOnlineSlider.addEventListener("change", updateResults);
}